<?php
error_reporting(1);
session_start();
$i=$_REQUEST['img'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
$i=$_REQUEST['img'];
if($_POST['ord'])
{ 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=ord.rand(100,500);
if(mysql_query("insert into orders values('','$prodno','$price','$name','$phone','$add','$ordno')"))
{
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersent.php?order_no=$ordno");  }
else {$error= "user already exists";}}

?>
<!DOCTYPE html>
<html lang="en">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>FASHION STORE PAGE</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-lugx-gaming.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 589 lugx gaming

https://templatemo.com/tm-589-lugx-gaming

-->
<style>
		nav{
			background: rgba(96,69,225,0.53);
			width: 100%;
			height: 60px;
			background-size: cover;
		}
		nav ul{
			float: right;
			display: flex;
			background-size: cover;
		}
		nav ul li a{
					color: green;
					line-height: 60px;
					padding: 20px 120px;
					font-size: 18px;
					text-decoration: none;
					border-radius: 3px;
					margin-right: 10px;
		}
		nav ul li a:hover{
							background: rgba(244,8,130,0.8);
		}
</style>
  </head>
  <body>

  <header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.html" class="logo">
					<h6><b>FASHION STORE</b></h6>
                        <img src="assets/images/bask.png" alt="" style="width: 158px;">
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->
			</br></br></br></br></br>
			<h3 align="center" class="form"><u>Order Form</u></h3>
			</br></br>
					<nav>
                    <ul>
                      <li><a href="index.html" class="active">Home</a></li>
                      <li><a href="register.html">Register</a></li>
                      <li><a href="product.html">Product</a></li>
                      <li><a href="contact.html">Contact</a></li>
                  </ul>   
					</nav>
			</br></br>
			
        <?php
			include("connection.php");
			$sel=mysql_query("select * from item  where img='$i' ");
			$mat=mysql_fetch_array($sel);
			
			
			?>
            <form  method="post">
				
                <label align="center">Product-Name </label>
                <input type="text" name="prodno" id="prodno"  value="<?php echo $mat['Prod_No'];?>" class="input_field" />
				</br></br>
                <label>Price  </label>
                <input type="text" name="price" id="price" value="<?php echo $mat['Price'];?>" class="input_field" />
				</br></br>
				 <label>Name </label>
                <input type="text" name="nam" id="nam" class="input_field" />
				</br></br>
				 <label>Phone </label>
                <input type="text" name="pho" id="php" class="input_field" />
				</br></br>
				 <label>Address</label>
                <textarea id="add" name="add" rows="0" cols="0" class="required"></textarea>
				 
                <input type="submit" name="ord" id="ord" value="sent order" class="submit_button" />
				 <input type="submit" name="Cancel" value="Cancel" class="submit_button" />
				
            </form>  

<footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2048 FASHION STORE Company. All rights reserved. &nbsp;&nbsp; <a rel="nofollow" href="https://templatemo.com" target="_blank">Design: Aung Chan Myae.</a></p>
      </div>
    </div>
  </footer>
</body>
</html>