<?php
	error_reporting(1);
	
	include("connection.php");
	
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
	}
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>FASHION STORE PAGE</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-lugx-gaming.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 589 lugx gaming

https://templatemo.com/tm-589-lugx-gaming

-->
	<style>
		nav{
			background: rgba(0,255,255,1);
			width: 100%;
			height: 60px;
			background-size: cover;
		}
		nav ul{
			float: right;
			display: flex;
			background-size: cover;
		}
		nav ul li a{
					color: green;
					line-height: 60px;
					padding: 20px 120px;
					font-size: 17px;
					text-decoration: none;
					border-radius: 6px;
					margin-right: 10px;
		}
		nav ul li a:hover{
							background: rgba(0,0,255,1);
		}
</style>
  </head>
  <body>


    	<a href="index.html" class="logo">
					<h6><b>FASHION STORE</b></h6>
                        <img src="assets/images/bask.png" alt="" style="width: 158px;">
                    </a>
		<nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="product.php" class="selected">Product</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
		</nav>	
    	<br><br>
      <h2><span>Thank you for shopping with us</span></h2>
          <p><font color="blue"><i>Order sent successfully!</i></font></p>
		  <p>Your order no. is <?php echo "<font size='4' color='blue'>".$_REQUEST['order_no']."</font>";?></p>
		  <p>Thank you. Please come again.</p>
		  <p><a href="?log=out">Log out</a></p> 

<footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2048 FASHION STORE Company. All rights reserved. &nbsp;&nbsp; <a rel="nofollow" href="https://templatemo.com" target="_blank">Design: Aung Chan Myae.</a></p>
      </div>
    </div>
  </footer>
</body>
</html>