<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>FASHION STORE - Home Page!</title>

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-lugx-gaming.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>

  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.php" class="logo">
					<p><b>FASHION STORE</b></p>
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                      <li><a href="index.php" class="active">Home</a></li>
                      <li><a href="register.php">Register</a></li>
                      <li><a href="product.php">Product</a></li>
                      <li><a href="contact.php">Contact</a></li>
                      <li><a href="#">Sign In</a></li>
                  </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="main-banner">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 align-self-center">
          <div class="caption header-text">
            <h6>Welcome to our FASHION STORE</h6>
            <h2>BEST SHOPPING SITE EVER!</h2>
            <p>Hello our customers!What would your like to buy?We have special and latest designs of coats, watches,umbrellas, shoes,bags & books!
			   We have special promotions for you,Guys!If you buy above three things,you can get special promotion as you like.</p>
            <div class="search-input">
              <form id="search" action="#">
                <input type="text" placeholder="Type Something" id='searchText' name="searchKeyword" onkeypress="handle" />
                <button role="button">Search Now</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-4 offset-lg-2">
          <div class="right-image">
            <img src="assets/images/shopping.jpg" alt="">
            <span class="price">$500000</span>
            <span class="offer">-25%</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="features">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <a href="#">
            <div class="item">
              <div class="image">
                <a href="product.php"><img src="assets/images/men4.jpg" alt="" style="max-width: 44px;"></a>
              </div>
              <h4><a href="product.php">COATS</a></h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="#">
            <div class="item">
              <div class="image">
                <a href="product.php"><img src="assets/images/wa2.jpg" alt="" style="max-width: 44px;"></a>
              </div>
              <h4><a href="product.php">WATCHES</a></h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="#">
            <div class="item">
              <div class="image">
                <a href="product.php"><img src="assets/images/shoe5.jpg" alt="" style="max-width: 44px;"></a>
              </div>
              <h4><a href="product.php">SHOES</a></h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="#">
            <div class="item">
              <div class="image">
                <a href="product.php"><img src="assets/images/bag4.jpg" alt="" style="max-width: 44px;"></a>
              </div>
              <h4><a href="product.php">BAGS</a></h4>
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>

  <div class="section trending">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="section-heading">
		  <p><b>The other two things are special promotions for our customers.You guys,can choose as you like.(Books or Umbrellas)</b></p>
            <h6>Trending</h6>
            <h2>Trending Fashion</h2>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="main-button">
            <a href="product.php">View All</a>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/coat.jpg" alt=""></a>
              <span class="price"><em>$100000</em>$85000</span>
            </div>
            <div class="down-content">
              <span class="category">COATS</span>
              <h4>New coats are avaiable now!</h4>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/watch.jpg" alt=""></a>
              <span class="price"><em>$60000</em>$50000</span>
            </div>
            <div class="down-content">
              <span class="category">WATCHES</span>
              <h4>New watches are avaiable now!</h4>
              <
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/bag5.jpg" alt=""></a>
              <span class="price"><em>$75000</em>$70000</span>
            </div>
            <div class="down-content">
              <span class="category">BAGS</span>
              <h4>New bags are avaiable now!</h4>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/shoes.jpg" alt=""></a>
              <span class="price"><em>$65000</em>$70000</span>
            </div>
            <div class="down-content">
              <span class="category">SHOES</span>
              <h4>New shoes are avaiable now!</h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="section most-played">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="section-heading">
            <h6>TOP FASHION</h6>
            <h2>Most PREORDER PRODUCT!</h2>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="main-button">
            <a href="product.php">View All</a>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 col-sm-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/men4.jpg" alt=""></a>
            </div>
            <div class="down-content">
                <span class="category">JACKETS</span>
                <h4>Clothing</h4>
                <a href="product.php">Explore</a>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 col-sm-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/wa6.jfif" alt=""></a>
            </div>
            <div class="down-content">
                <span class="category">WATCHES</span>
                <h4>TIMING</h4>
                <a href="product.php">Explore</a>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 col-sm-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/ba.jpg" alt=""></a>
            </div>
            <div class="down-content">
                <span class="category">BAGS</span>
                <h4>EDUCATION</h4>
                <a href="product.php">Explore</a>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 col-sm-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/sho.jfif" alt=""></a>
            </div>
            <div class="down-content">
                <span class="category">SHOES</span>
                <h4>STYLE</h4>
                <a href="product.php">Explore</a>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 col-sm-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/umbre4.jfif" alt=""></a>
            </div>
            <div class="down-content">
                <span class="category">UMBRELLAS</span>
                <h4>SEASONAL</h4>
                <a href="product.php">Explore</a>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 col-sm-6">
          <div class="item">
            <div class="thumb">
              <a href="product.php"><img src="assets/images/book1.jpg" alt=""></a>
            </div>
            <div class="down-content">
                <span class="category">BOOKS</span>
                <h4>KNOWLEDGE</h4>
                <a href="product.php">Explore</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="section categories">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <div class="section-heading">
            <h6>Trending Fashion</h6>
            <h2>Most Pre-Order Things!</h2>
          </div>
        </div>
        <div class="col-lg col-sm-6 col-xs-12">
          <div class="item">
            <h4>COATS</h4>
            <div class="thumb">
              <a href="product.php"><img src="assets/images/men1.jpg" alt=""></a>
            </div>
          </div>
        </div>
        <div class="col-lg col-sm-6 col-xs-12">
          <div class="item">
            <h4>WATCHES</h4>
            <div class="thumb">
              <a href="product.php"><img src="assets/images/wa3.jpg" alt=""></a>
            </div>
          </div>
        </div>
        <div class="col-lg col-sm-6 col-xs-12">
          <div class="item">
            <h4>BAGS<h4>
            <div class="thumb">
              <a href="product.php"><img src="assets/images/bag1.jpg" alt=""></a>
            </div>
          </div>
        </div>
        <div class="col-lg col-sm-6 col-xs-12">
          <div class="item">
            <h4>SHOES</h4>
            <div class="thumb">
              <a href="product.php"><img src="assets/images/shoe4.jpg" alt=""></a>
            </div>
          </div>
        </div>
        <div class="col-lg col-sm-6 col-xs-12">
          <div class="item">
            <h4>UMBRELLAS</h4>
            <div class="thumb">
              <a href="product.php"><img src="assets/images/R.jfif" alt=""></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  


  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2048 FASHION STORE Company. All rights reserved. &nbsp;&nbsp; <a rel="nofollow" href="https://templatemo.com" target="_blank">Design: Aung Chan Myae.</a></p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>

  </body>
</html>