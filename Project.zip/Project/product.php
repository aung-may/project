<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>Fashion Store - Product Page!</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-lugx-gaming.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 589 lugx gaming

https://templatemo.com/tm-589-lugx-gaming

-->
  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.php" class="logo">
					<p><b>FASHION STORE</b></p>
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                      <li><a href="index.php">Home</a></li>
                      <li><a href="register.php">Register</a></li>
                      <li><a href="product.php" class="active">Product</a></li>
                      <li><a href="contact.php">Contact</a></li>
                      <li><a href="#">Sign In</a></li>
                  </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="page-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h3>Latest Design of FASHION!</h3>
          <span class="breadcrumb"><a href="#">Home</a>  >  <a href="#">Register</a>  >  Product</span>
        </div>
      </div>
    </div>
  </div>

  <div class="single-product section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="left-image">
            <img src="assets/images/shopping.jpg" alt=""></br></br>
			  <img src="assets/images/shop.gif" alt="" style="max-width: 400px;"></br></br>
			  <img src="assets/images/shop1.gif" alt="" style="max-width: 300px;">
          </div>
        </div>
        <div class="col-lg-6 align-self-center">
          <h4>Warmly Welcome to our FASHION STORE!</h4>
          <span class="price"><em>$400000</em> $25% OFF</span>
          <p>We have special brand new things such as coats,watches,umbrellas,bags & books.At this time,if you buy more than three things you guys will get 25% discount.
			[#This promotion is only form June to October!#]Thank you for your support.</p>
          <form id="qty" action="#">
            <input type="qty" class="form-control" id="1" aria-describedby="quantity" placeholder="1">
            <button type="submit"><i class="fa fa-shopping-bag"></i> ADD TO CART</button>
          </form>
          <ul>
            <li><span>Things ID:</span><a href="#"><input type="tid" placeholder="As given number on item?" readonly></a></li>
            <li><span>Sex:</span><a href="#"><input type="name" placeholder="Male or Female?" readonly></a></li>
            <li><span>Mail:</span> <a href="#"><input type="name" placeholder="Your mail@gmail.com?" readonly></a></li>
			<li><span>Ph:</span><input type="name" placeholder="Your number?" readonly><a href="#"></a></li>
			<p>Please fill these required field in our contact page!</p>
          </ul>
        </div>
        <div class="col-lg-12">
          <div class="sep"></div>
        </div>
      </div>
    </div>
  </div>



  <div class="section categories related-games">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="section-heading">
            <h6>FASHION STORE</h6>
            <h2>Avaiable Things</h2>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="main-button">
            <a href="product.php">View All</a>
          </div>
        </div>
		 <div id="header_main">
     <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from item ");
						echo"<form method='post'><table border='0' align='center'><tr>";
   $n=0;
    while($arr=mysql_fetch_array($sel))
   {
   $i=$arr['Img'];
   
    if($n%4==0)
	{
	echo "<tr>";
	}
   echo "
   <td height='280' width='240' align='center'><img src='admin/image/$i' height='200' width='200'><br/>
 
 <b>product name:</b>".$arr['Prod_No'].
   "<br><b>Price:</b>&nbsp;".$arr['Price'].
  "<br><a href='login.php?img=$i'><b>Buy</b></a>
   
   </td>";
  
  $n++;

   }
   	  echo "</tr></table>
       </form>";
	?>	
       
        
        


  
  

  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2048 FASHION STORE Company. All rights reserved. &nbsp;&nbsp; <a rel="nofollow" href="https://templatemo.com" target="_blank">Design: Aung Chan Myae.</a></p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>

  </body>
</html>