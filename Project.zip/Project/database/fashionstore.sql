-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 29, 2023 at 08:06 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fashionstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `Con_ID` int(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Message` varchar(30) NOT NULL,
  PRIMARY KEY (`Con_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`Con_ID`, `Name`, `Email`, `Phone`, `Message`) VALUES
(1, 'Aung Aung', 'amyae6983@gmail.com', '0987654321', 'hahaha'),
(2, 'Aung Aung', 'amyae6983@gmail.com', '0987654321', 'ArBwarr');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `ID` int(20) NOT NULL AUTO_INCREMENT,
  `Img` varchar(20) NOT NULL,
  `Prod_No` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`ID`, `Img`, `Prod_No`, `Price`) VALUES
(1, 'coat1.jfif', 'gentlemen style coat', 60000),
(2, 'coat.jpg', 'Stylish Coat', 70000),
(3, 'men3.jpg', 'vacation code', 50000),
(4, 'men4.jpg', 'travel coat', 55000),
(6, 'bag5.jpg', 'smart bag', 60000),
(7, 'bag4.jpg', 'travel bag', 55000),
(8, 'ba.jpg', 'school bag', 70000),
(9, 'bag2.jpg', 'style bag', 50000),
(10, 'R.jfif', 'umbrella', 15000),
(11, 'umbre1.jpg', 'black umbrella', 15000),
(12, 'umbre3.jpg', 'red umbrella', 15000),
(13, 'umbre2.jpg', 'colorful umbrella', 15000),
(18, 'book.jpg', 'books for school', 10000),
(19, 'book1.jpg', 'literature for youth', 15000),
(20, 'book2.jpg', 'Science books', 20000),
(21, 'book4.jfif', 'Historical books', 30000),
(22, 'images (1).jfif', 'bicycle(boys)', 200000),
(23, 'images.jfif', 'bicycle(boys)', 200000),
(24, 'girl(1).jfif', 'bicycle(girls)', 150000),
(25, 'girl.jfif', 'bicycle(girls)', 150000),
(26, 'shoes.jpg', 'stylish shoe', 60000),
(27, 'white.webp', 'white shoes', 50000),
(28, 'brown.jfif', 'brown shoe', 55000),
(29, 'blue.jfif', 'blue shoes', 60000);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `ord_id` int(20) NOT NULL AUTO_INCREMENT,
  `productno` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `order_no` varchar(20) NOT NULL,
  PRIMARY KEY (`ord_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ord_id`, `productno`, `price`, `name`, `phone`, `address`, `order_no`) VALUES
(4, 'Stylish Coat', '70000', 'Aung Chan Myae', '09675185853', 'Yangon', 'ord431'),
(5, 'Stylish Coat', '70000', 'Aung Chan Myae', '09675185853', 'Ygn', 'ord366'),
(6, 'school bag', '70000', 'Zin Myo Htoon', '09675185853', 'Tharkaeta,Yangon', 'ord404'),
(7, 'gentlemen', '60000', 'MgMg', '09-675185853', 'Dagon Township', 'ord461'),
(8, 'school bag', '70000', 'Zin Myo Htoon', '0987654123', 'magway', 'ord288'),
(9, 'school bag', '60000', 'chocho', '09876543345', 'ygn', 'ord303'),
(10, 'stylish shoe', '60000', 'MgMg', '09675185853', 'ygn', 'ord388'),
(11, 'black umbrella', '15000', 'chocho', '09-675185853', 'somewhere', 'ord299');

-- --------------------------------------------------------

--
-- Table structure for table `registers`
--

CREATE TABLE IF NOT EXISTS `registers` (
  `Reg_ID` int(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Address` varchar(30) NOT NULL,
  PRIMARY KEY (`Reg_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `registers`
--

INSERT INTO `registers` (`Reg_ID`, `Name`, `Email`, `Password`, `Phone`, `Address`) VALUES
(7, 'Aung Aung', 'amyae6983@gmail.com', '1234', '09761737233', 'Ygn');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(20) NOT NULL,
  `pass` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `pass`) VALUES
('admin', 1234);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
